#!/usr/bin/env python3
"""
Efficient transposon candidate detection via inverted repeats (IRs).
- IR length: 4–6 bases
- Spacer length: 20–200 bases
- Optional TSD detection (2–8 bases)
- Progress printed every 50k bases
"""

from typing import List, Tuple, Optional
from dataclasses import dataclass

NUC_COMP = {'A':'T','T':'A','G':'C','C':'G'}

def rc(seq: str) -> str:
    return ''.join(NUC_COMP.get(b,'N') for b in reversed(seq))

def read_fasta(path: str) -> List[Tuple[str,str]]:
    records = []
    with open(path) as f:
        header, seq = None, []
        for line in f:
            line=line.strip()
            if not line: continue
            if line.startswith(">"):
                if header: records.append((header,''.join(seq).upper()))
                header=line[1:]
                seq=[]
            else:
                seq.append(line)
        if header: records.append((header,''.join(seq).upper()))
    return records

@dataclass
class Candidate:
    file: str
    contig: str
    start: int
    end: int
    ir_left: str
    ir_right: str
    spacer_len: int
    tsd: Optional[str]
    score: float

def find_tsd(seq: str, start: int, end: int, tsd_min=2, tsd_max=8) -> Optional[str]:
    for L in range(tsd_max, tsd_min-1, -1):
        if start-L>=0 and end+L<=len(seq):
            left=seq[start-L:start]
            right=seq[end:end+L]
            if left==right: return left
    return None

def detect_ir(seq: str, file: str, contig: str,
              ir_min=4, ir_max=6, spacer_min=20, spacer_max=200) -> List[Candidate]:
    n=len(seq)
    candidates=[]
    for i in range(n):
        if i%50000==0: print(f"  progress: {i}/{n} bases")
        for k in range(ir_min, ir_max+1):
            if i+k+spacer_min>=n: continue
            ir_left=seq[i:i+k]
            ir_right=rc(ir_left)
            # search downstream within spacer bounds
            for j in range(i+k+spacer_min, min(i+k+spacer_max, n-k)):
                if seq[j:j+k]==ir_right:
                    start=i+k
                    end=j
                    spacer_len=end-start
                    tsd=find_tsd(seq,start,end)
                    score=0.6+(0.2 if spacer_len>=4 else 0)+(0.2 if tsd else 0)
                    candidates.append(Candidate(file,contig,start,end,ir_left,ir_right,spacer_len,tsd,round(score,3)))
    return candidates

def write_tsv(cands: List[Candidate], out_path: str):
    with open(out_path,"w") as f:
        f.write("file\tcontig\tstart\tend\tlength\tir_left\tir_right\tspacer_len\ttsd\tscore\n")
        for c in cands:
            f.write(f"{c.file}\t{c.contig}\t{c.start}\t{c.end}\t{c.end-c.start}\t{c.ir_left}\t{c.ir_right}\t{c.spacer_len}\t{c.tsd or ''}\t{c.score}\n")

def main():
    fasta_files=["Bacillus.fasta","Escherichia.fasta","Pseudomonas.fasta"]
    all_cands=[]
    for file in fasta_files:
        for contig,seq in read_fasta(file):
            print(f"Scanning {file} :: {contig} :: length={len(seq)}")
            # for testing, limit to first 100k bases
            seq=seq[:100000]
            cands=detect_ir(seq,file,contig)
            print(f"  → Found {len(cands)} candidates")
            all_cands.extend(cands)
    write_tsv(all_cands,"candidates.tsv")
    print(f"[DONE] Wrote {len(all_cands)} candidates to candidates.tsv")

if __name__=="__main__":
    main()
