#!/usr/bin/env python3
"""
Transposon simulation and detection (best version)
- Generates a host DNA sequence (200–400 bp)
- Inserts 3–4 transposons with inverted repeats and target site duplications (direct repeats)
- Detects transposons by exact match and discovery (pattern scan)
- Outputs a report and files for submission
"""

import random
import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Tuple, Dict, Optional

NUCS = ['A', 'T', 'G', 'C']

def rc(seq: str) -> str:
    """Reverse-complement a DNA sequence."""
    comp = {'A':'T', 'T':'A', 'G':'C', 'C':'G'}
    return ''.join(comp[b] for b in reversed(seq))

def rand_dna(k: int) -> str:
    return ''.join(random.choice(NUCS) for _ in range(k))

def find_all(haystack: str, needle: str) -> List[int]:
    """Return all start indices where needle occurs in haystack."""
    starts = []
    i = haystack.find(needle)
    while i != -1:
        starts.append(i)
        i = haystack.find(needle, i + 1)
    return starts

@dataclass
class TransposonSpec:
    name: str
    ir_left: str          # inverted repeat (left)
    core: str             # central payload
    ir_right: str         # inverted repeat (right) = rc(ir_left)
    tsd: str              # target site duplication motif (direct repeat)

    @property
    def body(self) -> str:
        return f"{self.ir_left}{self.core}{self.ir_right}"

    def __len__(self) -> int:
        return len(self.body)

@dataclass
class InsertionRecord:
    name: str
    start: int
    end: int
    tsd: str

@dataclass
class DetectionRecord:
    mode: str             # 'exact' or 'discovery'
    start: int
    end: int
    ir_left: Optional[str] = None
    ir_right: Optional[str] = None
    tsd_left: Optional[str] = None
    tsd_right: Optional[str] = None
    score: float = 0.0

class TransposonSimulator:
    def __init__(
        self,
        host_len_range: Tuple[int, int] = (200, 400),
        n_transposons_range: Tuple[int, int] = (3, 4),
        ir_len_range: Tuple[int, int] = (6, 10),
        core_len_range: Tuple[int, int] = (10, 20),
        tsd_len_range: Tuple[int, int] = (2, 5),
        allow_overlap: bool = True,
        seed: Optional[int] = None
    ):
        if seed is not None:
            random.seed(seed)
        self.host_len = random.randint(*host_len_range)
        self.n_transposons = random.randint(*n_transposons_range)
        self.ir_len_range = ir_len_range
        self.core_len_range = core_len_range
        self.tsd_len_range = tsd_len_range
        self.allow_overlap = allow_overlap

    def generate_host(self) -> str:
        return rand_dna(self.host_len)

    def make_transposon(self, idx: int) -> TransposonSpec:
        ir_len = random.randint(*self.ir_len_range)
        core_len = random.randint(*self.core_len_range)
        tsd_len = random.randint(*self.tsd_len_range)
        ir_left = rand_dna(ir_len)
        core = rand_dna(core_len)
        ir_right = rc(ir_left)
        tsd = rand_dna(tsd_len)
        return TransposonSpec(name=f"T{idx+1}", ir_left=ir_left, core=core, ir_right=ir_right, tsd=tsd)

    def insert_transposons(self, host: str, specs: List[TransposonSpec]) -> Tuple[str, List[InsertionRecord]]:
        """
        Insert transposons with target site duplication (direct repeats flanking).
        Final sequence: host[:pos] + tsd + transposon + tsd + host[pos:]
        Overlap allowed by choosing nearby positions.
        """
        seq = host
        insertions: List[InsertionRecord] = []

        # Choose positions; if overlap allowed, pick arbitrary positions, else keep them separated
        positions = []
        for i in range(len(specs)):
            if self.allow_overlap:
                positions.append(random.randint(0, len(seq)))
            else:
                # pick positions spaced roughly evenly
                positions.append(int((i + 1) * len(seq) / (len(specs) + 1)))

        # Sort to maintain predictable left-to-right insertion, but we will recompute positions due to length changes
        for spec, _ in sorted(zip(specs, positions), key=lambda p: p[1]):
            # pick a fresh position each time to allow natural overlap growth
            pos = random.randint(0, len(seq))
            left = seq[:pos]
            right = seq[pos:]
            assembled = f"{spec.tsd}{spec.body}{spec.tsd}"
            seq = left + assembled + right
            start = len(left) + len(spec.tsd)  # start of transposon body (excluding TSD)
            end = start + len(spec.body)
            insertions.append(InsertionRecord(name=spec.name, start=start, end=end, tsd=spec.tsd))

        return seq, insertions

class TransposonDetector:
    def __init__(
        self,
        ir_len_range: Tuple[int, int] = (6, 12),
        tsd_len_range: Tuple[int, int] = (2, 6),
        max_gap_between_irs: int = 60
    ):
        self.ir_len_range = ir_len_range
        self.tsd_len_range = tsd_len_range
        self.max_gap_between_irs = max_gap_between_irs

    def detect_exact(self, dna: str, specs: List[TransposonSpec]) -> List[DetectionRecord]:
        detections: List[DetectionRecord] = []
        for spec in specs:
            body = spec.body
            for start in find_all(dna, body):
                end = start + len(body)
                # Try to capture TSD flanks if present
                tsd_len = len(spec.tsd)
                tsd_left = dna[start - tsd_len:start] if start - tsd_len >= 0 else None
                tsd_right = dna[end:end + tsd_len] if end + tsd_len <= len(dna) else None
                det = DetectionRecord(
                    mode="exact",
                    start=start,
                    end=end,
                    ir_left=spec.ir_left,
                    ir_right=spec.ir_right,
                    tsd_left=tsd_left,
                    tsd_right=tsd_right,
                    score=1.0
                )
                detections.append(det)
        return detections

    def detect_discovery(self, dna: str) -> List[DetectionRecord]:
        """
        Discovery mode: scan for candidate transposons using:
        - Pairs of inverted repeats (IR_left and IR_right=rc(IR_left)) within a window
        - Optional presence of flanking direct repeats (TSD) of small length
        """
        detections: List[DetectionRecord] = []
        n = len(dna)

        # Precompute reverse complements of all windows? Keep it straightforward and efficient enough for ~1KB.
        for ir_len in range(self.ir_len_range[0], self.ir_len_range[1] + 1):
            # Slide for left IR
            for i in range(0, n - ir_len + 1):
                ir_left = dna[i:i + ir_len]
                ir_right_target = rc(ir_left)

                # Find candidate right IR within max gap
                search_start = i + ir_len
                search_end = min(n, search_start + self.max_gap_between_irs + ir_len)
                # Scan region for exact right IR match
                j = dna.find(ir_right_target, search_start, search_end)
                while j != -1:
                    # Candidate interval: [i + ir_len, j)
                    body_start = i + ir_len
                    body_end = j
                    # Check TSDs around body: small direct repeats to left/right of body region
                    best_tsd = None
                    tsd_left = None
                    tsd_right = None
                    tsd_score = 0.0
                    for tsd_len in range(self.tsd_len_range[0], self.tsd_len_range[1] + 1):
                        left_start = body_start - tsd_len
                        right_end = body_end + tsd_len
                        if left_start >= 0 and right_end <= n:
                            left_motif = dna[left_start:body_start]
                            right_motif = dna[body_end:body_end + tsd_len]
                            if left_motif == right_motif:
                                # Prefer longer TSDs (stronger signal)
                                if best_tsd is None or tsd_len > len(best_tsd):
                                    best_tsd = left_motif
                                    tsd_left = left_motif
                                    tsd_right = right_motif
                                    tsd_score = 0.2 + 0.1 * tsd_len  # small contribution by length

                    # Score: IR presence + body length sanity + TSD evidence
                    body_len = body_end - body_start
                    # Reasonable body length check (payload should exist)
                    has_payload = body_len >= 4
                    score = 0.0
                    # IRs aligned
                    score += 0.6
                    # Payload sanity
                    score += 0.2 if has_payload else 0.0
                    # TSD evidence
                    score += tsd_score

                    detections.append(DetectionRecord(
                        mode="discovery",
                        start=body_start,
                        end=body_end,
                        ir_left=ir_left,
                        ir_right=ir_right_target,
                        tsd_left=tsd_left,
                        tsd_right=tsd_right,
                        score=round(score, 3)
                    ))
                    # Continue searching for other right IR matches in window
                    j = dna.find(ir_right_target, j + 1, search_end)

        # De-duplicate overlapping candidates: keep highest-score per (start,end)
        unique: Dict[Tuple[int,int], DetectionRecord] = {}
        for det in detections:
            key = (det.start, det.end)
            if key not in unique or det.score > unique[key].score:
                unique[key] = det
        return sorted(unique.values(), key=lambda d: (d.start, d.end, -d.score))

def pretty_interval(s: int, e: int) -> str:
    return f"[{s}, {e}) len={e - s}"

def simulate_and_detect(
    seed: Optional[int] = 42,
    allow_overlap: bool = True,
    host_len_range: Tuple[int, int] = (200, 400),
    n_transposons_range: Tuple[int, int] = (3, 4),
) -> Dict:
    sim = TransposonSimulator(
        host_len_range=host_len_range,
        n_transposons_range=n_transposons_range,
        allow_overlap=allow_overlap,
        seed=seed
    )
    host = sim.generate_host()
    specs = [sim.make_transposon(i) for i in range(sim.n_transposons)]
    final_seq, insertions = sim.insert_transposons(host, specs)

    det = TransposonDetector()
    exact = det.detect_exact(final_seq, specs)
    discovery = det.detect_discovery(final_seq)

    return {
        "host_len": len(host),
        "final_len": len(final_seq),
        "host": host,
        "final_seq": final_seq,
        "transposons": [asdict(s) | {"length": len(s)} for s in specs],
        "insertions": [asdict(i) for i in insertions],
        "exact_detections": [asdict(d) for d in exact],
        "discovery_detections": [asdict(d) for d in discovery],
    }

def print_report(result: Dict) -> None:
    print("=== Simulation report ===")
    print(f"- Host length: {result['host_len']}")
    print(f"- Final length: {result['final_len']}")
    print(f"- Number of transposons: {len(result['transposons'])}")
    print("\n=== Inserted transposons ===")
    for t in result["transposons"]:
        print(f"* {t['name']}: len={t['length']}, ir_left={t['ir_left']}, ir_right={t['ir_right']}, core_len={len(t['core'])}, tsd={t['tsd']}")

    print("\n=== Insertions (ground truth) ===")
    for ins in result["insertions"]:
        print(f"* {ins['name']}: body {pretty_interval(ins['start'], ins['end'])}, tsd={ins['tsd']}")

    print("\n=== Exact detections ===")
    if not result["exact_detections"]:
        print("* None")
    else:
        for d in result["exact_detections"]:
            print(f"* {d['mode']} {pretty_interval(d['start'], d['end'])} irL={d['ir_left']} irR={d['ir_right']} tsdL={d['tsd_left']} tsdR={d['tsd_right']} score={d['score']}")

    print("\n=== Discovery detections (top 10 by score) ===")
    if not result["discovery_detections"]:
        print("* None")
    else:
        top = sorted(result["discovery_detections"], key=lambda x: -x["score"])[:10]
        for d in top:
            print(f"* {d['mode']} {pretty_interval(d['start'], d['end'])} irL={d['ir_left']} irR={d['ir_right']} tsdL={d['tsd_left']} tsdR={d['tsd_right']} score={d['score']}")

def save_outputs(result: Dict, out_prefix: str = "L9") -> None:
    # Save JSON summary
    with open(f"{out_prefix}_result.json", "w") as f:
        json.dump(result, f, indent=2)

    # Save sequences
    with open(f"{out_prefix}_host.txt", "w") as f:
        f.write(result["host"] + "\n")
    with open(f"{out_prefix}_final.txt", "w") as f:
        f.write(result["final_seq"] + "\n")

    # Save a simple README template to include in Project_L9.zip
    with open("ReadMe.txt", "w") as f:
        f.write("Project L9 - Transposon Simulation and Detection\n")
        f.write("Team: Huda\n")
        f.write("Components:\n")
        f.write("- Simulator and detector in Python (single script)\n")
        f.write("- Console screenshot(s)\n")
        f.write("- Source code and compiled bytecode (optional)\n")
        f.write("\nHow to run:\n")
        f.write("python3 transposon.py --seed 42 --overlap\n")

def main():
    parser = argparse.ArgumentParser(description="Transposon simulation and detection")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    parser.add_argument("--no-overlap", action="store_true", help="Disallow overlapping insertions")
    parser.add_argument("--host-min", type=int, default=200, help="Minimum host length")
    parser.add_argument("--host-max", type=int, default=400, help="Maximum host length")
    parser.add_argument("--out-prefix", type=str, default="L9", help="Output file prefix")
    parser.add_argument("--save", action="store_true", help="Save outputs to files")
    args = parser.parse_args()

    result = simulate_and_detect(
        seed=args.seed,
        allow_overlap=not args.no_overlap,
        host_len_range=(args.host_min, args.host_max)
    )

    print_report(result)
    if args.save:
        save_outputs(result, out_prefix=args.out_prefix)

if __name__ == "__main__":
    main()
