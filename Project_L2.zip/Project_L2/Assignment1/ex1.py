from collections import Counter
from itertools import product

# DNA sequence
S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

# Generate all possible combinations
nucleotides = ['A', 'T', 'C', 'G']
dinucleotides = [''.join(p) for p in product(nucleotides, repeat=2)]
trinucleotides = [''.join(p) for p in product(nucleotides, repeat=3)]

# Count all dinucleotides and trinucleotides in S
di_counts = Counter([S[i:i+2] for i in range(len(S)-1)])
tri_counts = Counter([S[i:i+3] for i in range(len(S)-2)])

# Total possible windows
total_di = len(S) - 1
total_tri = len(S) - 2

# Display percentages
print("🔹 Dinucleotide Percentages:")
for di in sorted(dinucleotides):
    percent = (di_counts[di] / total_di) * 100
    print(f"{di}: {percent:.2f}%")

print("\n🔹 Trinucleotide Percentages:")
for tri in sorted(trinucleotides):
    percent = (tri_counts[tri] / total_tri) * 100
    print(f"{tri}: {percent:.2f}%")
