S = "abaa"

found_dinucleotides = set()
found_trinucleotides = set()

for i in range(len(S)):
    
    if i + 1 < len(S):
        di = S[i:i+2]
        found_dinucleotides.add(di)
    
    
    if i + 2 < len(S):
        tri = S[i:i+3]
        found_trinucleotides.add(tri)


print("Dinucleotides found:", sorted(found_dinucleotides))
print("Trinucleotides found:", sorted(found_trinucleotides))
