# process_fasta_sliding.py
import os
from collections import Counter
import csv
import matplotlib.pyplot as plt

FASTA_FILENAME = "sequence.fasta"   # your file in the workspace
WINDOW_SIZE = 30                    # sliding window size (change if needed)
OUTPUT_CSV = f"{os.path.splitext(FASTA_FILENAME)[0]}_k{WINDOW_SIZE}_freqs.csv"

def read_fasta_sequence(path):
    """Read fasta, ignore lines starting with '>' and join sequence lines."""
    seq_parts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                continue
            seq_parts.append(line)
    seq = "".join(seq_parts).upper()
    return seq

def sliding_base_frequencies(seq, k):
    """Return window indices and freq lists for A,C,G,T across sliding windows."""
    xs = []
    freqs = {"A": [], "C": [], "G": [], "T": []}
    n = len(seq)
    if n < k:
        return xs, freqs
    for i in range(n - k + 1):
        window = seq[i:i+k]
        # count only A,C,G,T; ignore other characters in denominator
        c = Counter(ch for ch in window if ch in "ACGT")
        denom = sum(c[b] for b in "ACGT")
        xs.append(i + 1)  # use 1-based start position for the window
        if denom == 0:
            for b in "ACGT":
                freqs[b].append(0.0)
        else:
            for b in "ACGT":
                freqs[b].append(c.get(b, 0) / denom)
    return xs, freqs

def save_csv(path, xs, freqs):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["window_start_index", "A", "C", "G", "T"])
        for i in range(len(xs)):
            writer.writerow([xs[i], freqs["A"][i], freqs["C"][i], freqs["G"][i], freqs["T"][i]])
    print(f"Saved CSV: {path}")

def plot_freqs(xs, freqs, title=None):
    if not xs:
        print("No windows to plot (sequence shorter than window size).")
        return
    plt.figure(figsize=(10,5))
    plt.plot(xs, freqs["A"], label="A")
    plt.plot(xs, freqs["C"], label="C")
    plt.plot(xs, freqs["G"], label="G")
    plt.plot(xs, freqs["T"], label="T")
    plt.ylim(0, 1)
    plt.xlabel("Window start index (1-based)")
    plt.ylabel("Relative frequency")
    plt.title(title or f"Relative base frequencies (k={WINDOW_SIZE})")
    plt.legend()
    plt.grid(linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.show()

def main():
    if not os.path.isfile(FASTA_FILENAME):
        print(f"Error: {FASTA_FILENAME} not found in current folder.")
        return

    seq = read_fasta_sequence(FASTA_FILENAME)
    print(f"Sequence length: {len(seq)}")
    xs, freqs = sliding_base_frequencies(seq, WINDOW_SIZE)
    if xs:
        print(f"Number of sliding windows (len - k + 1): {len(xs)}")
    else:
        print("No windows computed (sequence shorter than window).")

    # save results
    save_csv(OUTPUT_CSV, xs, freqs)

    # plot
    plot_freqs(xs, freqs, title=f"{FASTA_FILENAME} — k={WINDOW_SIZE}")

if __name__ == "__main__":
    main()
