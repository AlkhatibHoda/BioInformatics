import os
import math
from typing import List, Tuple, Dict
import matplotlib.pyplot as plt

ALPHABET = ["A", "C", "G", "T"]
IDX = {b: i for i, b in enumerate(ALPHABET)}


def read_fasta_sequence(path: str) -> str:
    seq_parts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(">"):
                continue
            seq_parts.append(line.upper())
    seq = "".join(seq_parts)
    seq = "".join(ch for ch in seq if ch in IDX)
    return seq

def read_all_fasta(folder: str) -> List[Tuple[str, str]]:
    files = sorted([fn for fn in os.listdir(folder) if fn.lower().endswith((".fasta", ".fa", ".fna"))])
    genomes = []
    for fn in files:
        path = os.path.join(folder, fn)
        seq = read_fasta_sequence(path)
        genomes.append((fn, seq))
    return genomes



def build_count_matrix(motifs: List[str]) -> List[List[int]]:
    L = len(motifs[0])
    counts = [[0] * L for _ in range(4)]
    for m in motifs:
        if len(m) != L:
            raise ValueError("All motifs must have the same length.")
        for j, ch in enumerate(m):
            if ch not in IDX:
                raise ValueError(f"Invalid base '{ch}' in motif.")
            counts[IDX[ch]][j] += 1
    return counts

def add_pseudocounts(counts: List[List[int]], pseudo: float = 1.0) -> List[List[float]]:
    L = len(counts[0])
    return [[counts[i][j] + pseudo for j in range(L)] for i in range(4)]

def relative_frequencies(weights: List[List[float]]) -> List[List[float]]:
    L = len(weights[0])
    freqs = [[0.0] * L for _ in range(4)]
    for j in range(L):
        col_sum = sum(weights[i][j] for i in range(4))
        for i in range(4):
            freqs[i][j] = weights[i][j] / col_sum
    return freqs

def log_likelihoods(freqs: List[List[float]], null_model: float = 0.25) -> List[List[float]]:
    L = len(freqs[0])
    return [[math.log(freqs[i][j] / null_model) for j in range(L)] for i in range(4)]


def score_window(window: str, ll: List[List[float]]) -> float:
    s = 0.0
    for j, ch in enumerate(window):
        s += ll[IDX[ch]][j]
    return s

def scan_sequence(S: str, ll: List[List[float]]) -> List[float]:
    L = len(ll[0])
    scores = []
    for start in range(0, len(S) - L + 1):
        w = S[start:start + L]
        
        if any(ch not in IDX for ch in w):
            scores.append(float("nan"))
        else:
            scores.append(score_window(w, ll))
    return scores



def top_peaks(scores: List[float], k: int = 5, min_distance: int = 20) -> List[int]:
    """Return indices of top k local maxima, spaced by min_distance."""
    n = len(scores)
    candidates = []
    for i in range(1, n - 1):
        if scores[i] > scores[i - 1] and scores[i] > scores[i + 1]:
            candidates.append(i)

    candidates.sort(key=lambda i: scores[i], reverse=True)

    chosen = []
    for i in candidates:
        if all(abs(i - c) >= min_distance for c in chosen):
            chosen.append(i)
        if len(chosen) == k:
            break
    return chosen

def mean_std(values: List[float]) -> Tuple[float, float]:
    vals = [v for v in values if not (isinstance(v, float) and math.isnan(v))]
    m = sum(vals) / len(vals)
    var = sum((x - m) ** 2 for x in vals) / len(vals)
    return m, math.sqrt(var)


def plot_scores(genome_name: str, scores: List[float], motif_len: int, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)

    m, sd = mean_std(scores)
    threshold = m + 2 * sd  

    peaks = top_peaks(scores, k=5, min_distance=max(10, motif_len * 2))

    x = list(range(len(scores)))

    plt.figure(figsize=(12, 4))
    plt.plot(x, scores)  
    plt.title(f"{genome_name} - Motif score signal (window={motif_len})")
    plt.xlabel("Start position (sliding window)")
    plt.ylabel("Log-likelihood score")

    
    plt.axhline(threshold, linestyle="--")

    for p in peaks:
        plt.axvline(p, linestyle=":")
        plt.text(p, scores[p], f" {p}", rotation=90, va="bottom")

    strong_hits = [p for p in peaks if scores[p] >= threshold]
    plt.tight_layout()

    out_path = os.path.join(out_dir, f"{os.path.splitext(genome_name)[0]}_signal.png")
    plt.savefig(out_path, dpi=200)
    plt.close()

    return out_path, strong_hits, threshold


def main():
    # --------- 1) Your known motif sequences (from your previous task) ----------
    motifs = [
        "GAGGTAAAC",
        "TCCGTAAGT",
        "CAGGTTGGA",
        "ACAGTCAGT",
        "TAGGTCATT",
        "TAGGTACTG",
        "ATGGTAACT",
        "CAGGTATAC",
        "TGTGTGAGT",
        "AAGGTAAGT",
    ]

    # --------- 2) Build the log-likelihood matrix ----------
    pseudo = 1.0
    null_model = 0.25

    counts = build_count_matrix(motifs)
    weights = add_pseudocounts(counts, pseudo=pseudo)
    freqs = relative_frequencies(weights)
    ll = log_likelihoods(freqs, null_model=null_model)

    motif_len = len(motifs[0])

    # --------- 3) Read and scan all influenza genomes ----------
    fasta_folder = "FastaFiles"
    genomes = read_all_fasta(fasta_folder)
    if not genomes:
        raise RuntimeError(f"No FASTA files found in: {fasta_folder}")

    out_dir = "Results"
    print(f"Found {len(genomes)} FASTA files. Scanning...")

    for name, seq in genomes:
        if len(seq) < motif_len:
            print(f"[SKIP] {name}: sequence too short.")
            continue

        scores = scan_sequence(seq, ll)
        img_path, strong_hits, thr = plot_scores(name, scores, motif_len, out_dir)

        best_pos = max(range(len(scores)), key=lambda i: scores[i])
        print(f"\n{name}")
        print(f"  length={len(seq)} windows={len(scores)}")
        print(f"  best hit at start={best_pos} score={scores[best_pos]:.3f}")
        print(f"  threshold(mean+2std)={thr:.3f}")
        if strong_hits:
            print(f"  strong peak positions: {strong_hits}")
        else:
            print("  strong peak positions: none (no peaks above threshold)")
        print(f"  saved chart: {img_path}")

    print(f"\nDone. Charts are in: {out_dir}/")

if __name__ == "__main__":
    main()
