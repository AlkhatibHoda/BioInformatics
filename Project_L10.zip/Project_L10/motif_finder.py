import math
from typing import List, Dict, Tuple

ALPHABET = ["A", "C", "G", "T"]
IDX = {b: i for i, b in enumerate(ALPHABET)}

def build_count_matrix(motifs: List[str]) -> List[List[int]]:
    L = len(motifs[0])
    counts = [[0] * L for _ in range(4)]
    for m in motifs:
        if len(m) != L:
            raise ValueError("All motifs must have the same length.")
        for j, ch in enumerate(m):
            if ch not in IDX:
                raise ValueError(f"Invalid base '{ch}' in motif.")
            counts[IDX[ch]][j] += 1
    return counts

def add_pseudocounts(counts: List[List[int]], pseudo: float = 1.0) -> List[List[float]]:
    L = len(counts[0])
    weights = [[0.0] * L for _ in range(4)]
    for i in range(4):
        for j in range(L):
            weights[i][j] = counts[i][j] + pseudo
    return weights

def relative_frequencies(weights: List[List[float]]) -> List[List[float]]:
    L = len(weights[0])
    freqs = [[0.0] * L for _ in range(4)]
    for j in range(L):
        col_sum = sum(weights[i][j] for i in range(4))
        for i in range(4):
            freqs[i][j] = weights[i][j] / col_sum
    return freqs

def log_likelihoods(freqs: List[List[float]], null_model: float = 0.25) -> List[List[float]]:
    L = len(freqs[0])
    ll = [[0.0] * L for _ in range(4)]
    for i in range(4):
        for j in range(L):
            ll[i][j] = math.log(freqs[i][j] / null_model)  # ln
    return ll

def score_window(window: str, ll: List[List[float]]) -> float:
    L = len(ll[0])
    if len(window) != L:
        raise ValueError("Window length must match motif length.")
    s = 0.0
    for j, ch in enumerate(window):
        if ch not in IDX:
            raise ValueError(f"Invalid base '{ch}' in sequence.")
        s += ll[IDX[ch]][j]
    return s

def scan_sequence(S: str, ll: List[List[float]]) -> List[Tuple[int, str, float]]:
    L = len(ll[0])
    results = []
    for start in range(0, len(S) - L + 1):
        w = S[start:start+L]
        sc = score_window(w, ll)
        results.append((start, w, sc))
    return results

def print_matrix(title: str, mat, fmt="{:>6}"):
    print("\n" + title)
    header = "      " + "".join([f"{j+1:>6}" for j in range(len(mat[0]))])
    print(header)
    for i, row_name in enumerate(ALPHABET):
        row = "".join(fmt.format(mat[i][j]) for j in range(len(mat[0])))
        print(f"{row_name:>3}  {row}")

def main():
    # Motifs transcribed from your image (10 sequences, length 9)
    motifs = [
        "GAGGTAAAC",
        "TCCGTAAGT",
        "CAGGTTGGA",
        "ACAGTCAGT",
        "TAGGTCATT",
        "TAGGTACTG",
        "ATGGTAACT",
        "CAGGTATAC",
        "TGTGTGAGT",
        "AAGGTAAGT",
    ]

    S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"

    pseudo = 1.0
    null_model = 0.25

    counts = build_count_matrix(motifs)
    weights = add_pseudocounts(counts, pseudo=pseudo)
    freqs = relative_frequencies(weights)
    ll = log_likelihoods(freqs, null_model=null_model)

    print_matrix("1) Count matrix (A,C,G,T x positions)", counts, fmt="{:>6d}")
    print_matrix(f"2) Weight matrix (count + pseudocount={pseudo})", weights, fmt="{:>6.1f}")
    print_matrix("3) Relative frequencies matrix", freqs, fmt="{:>6.3f}")
    print_matrix("4) Log-likelihoods matrix: ln(freq/0.25)", ll, fmt="{:>6.3f}")

    results = scan_sequence(S, ll)

    print("\n5) Sliding window scores on S (window length = 9)")
    print("Start  Window       Score")
    print("-" * 28)
    for start, w, sc in results:
        print(f"{start:>5}  {w}  {sc:>8.3f}")

    best = max(results, key=lambda x: x[2])
    print("\nBest hit:")
    print(f"Start={best[0]}, Window={best[1]}, Score={best[2]:.3f}")

    # Simple “signal” interpretation:
    # if best score is clearly above the average, it suggests motif-like region.
    scores = [x[2] for x in results]
    avg = sum(scores) / len(scores)
    var = sum((x - avg) ** 2 for x in scores) / len(scores)
    std = math.sqrt(var)
    print(f"\nScore stats: mean={avg:.3f}, std={std:.3f}")
    print("Rule of thumb: a strong signal is score > mean + 2*std")

    threshold = avg + 2 * std
    hits = [r for r in results if r[2] > threshold]
    if hits:
        print("\nSignal detected (windows above mean+2*std):")
        for start, w, sc in hits:
            print(f"  start={start:>2}  {w}  score={sc:.3f}")
        print("\nConclusion: YES, S likely contains an exon-intron border-like motif region.")
    else:
        print("\nNo strong outliers above mean+2*std.")
        print("Conclusion: NOT a clear signal (based on this threshold).")

if __name__ == "__main__":
    main()
