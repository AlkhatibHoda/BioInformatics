import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import math

ALPHABET = ["A", "C", "G", "T"]
IDX = {b: i for i, b in enumerate(ALPHABET)}

def build_pwm(motifs, pseudo=1.0, null_model=0.25):
    L = len(motifs[0])
    counts = [[0]*L for _ in range(4)]
    for m in motifs:
        for j, ch in enumerate(m):
            counts[IDX[ch]][j] += 1

    weights = [[counts[i][j] + pseudo for j in range(L)] for i in range(4)]
    freqs = []
    for j in range(L):
        col = [weights[i][j] for i in range(4)]
        s = sum(col)
        freqs.append([col[i]/s for i in range(4)])
    freqs = [[freqs[j][i] for j in range(L)] for i in range(4)]

    ll = [[math.log(freqs[i][j] / null_model) for j in range(L)] for i in range(4)]
    return counts, weights, freqs, ll

def score_window(window, ll):
    s = 0.0
    for j, ch in enumerate(window):
        s += ll[IDX[ch]][j]
    return s

def scan(S, ll):
    L = len(ll[0])
    out = []
    for start in range(len(S)-L+1):
        w = S[start:start+L]
        out.append((start, w, score_window(w, ll)))
    return out

def format_matrix(title, mat, fmt):
    L = len(mat[0])
    lines = []
    lines.append(title)
    lines.append("      " + "".join([f"{j+1:>7}" for j in range(L)]))
    for i, base in enumerate(ALPHABET):
        row = "".join([fmt.format(mat[i][j]) for j in range(L)])
        lines.append(f"{base:>3}  {row}")
    lines.append("")
    return "\n".join(lines)

def run_app():
    motifs = [
        "GAGGTAAAC",
        "TCCGTAAGT",
        "CAGGTTGGA",
        "ACAGTCAGT",
        "TAGGTCATT",
        "TAGGTACTG",
        "ATGGTAACT",
        "CAGGTATAC",
        "TGTGTGAGT",
        "AAGGTAAGT",
    ]
    S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"

    counts, weights, freqs, ll = build_pwm(motifs, pseudo=1.0, null_model=0.25)
    results = scan(S, ll)
    best = max(results, key=lambda x: x[2])

    scores = [x[2] for x in results]
    mean = sum(scores)/len(scores)
    std = (sum((x-mean)**2 for x in scores)/len(scores))**0.5
    thr = mean + 2*std
    hits = [r for r in results if r[2] > thr]

    root = tk.Tk()
    root.title("DNA Motif Finder (PWM + Log-likelihood)")

    txt = ScrolledText(root, width=110, height=35, font=("Consolas", 10))
    txt.pack(fill="both", expand=True)

    txt.insert("end", format_matrix("1) Count matrix", counts, "{:>7d}"))
    txt.insert("end", format_matrix("2) Weight matrix (count+pseudo)", weights, "{:>7.1f}"))
    txt.insert("end", format_matrix("3) Relative frequencies", freqs, "{:>7.3f}"))
    txt.insert("end", format_matrix("4) Log-likelihoods ln(freq/0.25)", ll, "{:>7.3f}"))

    txt.insert("end", "5) Sliding window scores\n")
    txt.insert("end", "Start  Window       Score\n")
    txt.insert("end", "-"*34 + "\n")
    for start, w, sc in results:
        txt.insert("end", f"{start:>5}  {w}  {sc:>8.3f}\n")

    txt.insert("end", f"\nBest hit: start={best[0]}, window={best[1]}, score={best[2]:.3f}\n")
    txt.insert("end", f"Stats: mean={mean:.3f}, std={std:.3f}, threshold(mean+2std)={thr:.3f}\n")
    if hits:
        txt.insert("end", "Signal: YES (hits above threshold)\n")
        for h in hits:
            txt.insert("end", f"  start={h[0]:>2}  {h[1]}  score={h[2]:.3f}\n")
    else:
        txt.insert("end", "Signal: NOT clear (no hits above threshold)\n")

    txt.configure(state="disabled")
    root.mainloop()

if __name__ == "__main__":
    run_app()
