from __future__ import annotations
import sys
import random
from collections import Counter
from pathlib import Path
from typing import List, Tuple

import matplotlib.pyplot as plt
import numpy as np
from Bio import Entrez, SeqIO

try:
    from tqdm import tqdm
    USE_TQDM = True
except ImportError:
    USE_TQDM = False

# -----------------------------
# USER CONFIGURATION
# -----------------------------
EMAIL = "you@example.com"       # REQUIRED: put your email here
API_KEY = None                  # Optional: your NCBI API key
KMIN = 6                        # minimum k-mer length
KMAX = 10                       # maximum k-mer length
MIN_LEN = 1000                  # minimum sequence length
MAX_LEN = 3000                  # maximum sequence length
INFLUENZA_N = 10                # number of influenza sequences to fetch
TOP_N = 30                      # top-N repeat units to plot
SEED = 42                       # random seed
OUTDIR = "plots"                # output folder
MIN_CONSECUTIVE_REPEATS = 2     # minimum consecutive repeats for tandem detection

# -----------------------------
# NCBI / Entrez setup
# -----------------------------
def set_entrez(email: str, api_key: str | None = None):
    if not email or "@" not in email:
        raise ValueError("Provide a valid email for NCBI Entrez")
    Entrez.email = email
    if api_key:
        Entrez.api_key = api_key

def search_ids(term: str, db: str = "nuccore", retmax: int = 50) -> List[str]:
    with Entrez.esearch(db=db, term=term, retmax=retmax) as handle:
        rec = Entrez.read(handle)
    return rec.get("IdList", [])

def fetch_fasta(seq_id: str, db: str = "nuccore") -> Tuple[str, str]:
    with Entrez.efetch(db=db, id=seq_id, rettype="fasta", retmode="text") as h:
        fasta_text = h.read()
    from io import StringIO
    record = next(SeqIO.parse(StringIO(fasta_text), "fasta"))
    return record.description, str(record.seq).upper().replace("U", "T")

# -----------------------------
# Search templates
# -----------------------------
INFLUENZA_TERM = (
    '"Influenza A virus"[Organism] AND (ha[Gene] OR hemagglutinin[Title]) '
    'AND ("complete cds"[Title] OR cds[Title]) AND {min}:{max}[SLEN]'
)

GENOMIC_TERM = (
    'biomol_genomic[PROP] AND srcdb_refseq[PROP] '
    'AND {min}:{max}[SLEN] NOT mitochondrion[Title]'
)

# -----------------------------
# Tandem repeat detection
# -----------------------------
def detect_tandem_repeats(seq: str, kmin: int, kmax: int, min_repeats: int) -> Counter:
    seq = seq.upper().replace("U", "T")
    counts = Counter()
    i, n = 0, len(seq)

    while i < n:
        matched = False
        for k in range(kmax, kmin - 1, -1):
            if i + k * min_repeats > n:
                continue
            unit = seq[i:i+k]
            if set(unit) - {"A", "C", "G", "T", "N"}:
                continue
            m = 1
            while i + (m+1)*k <= n and seq[i+m*k:i+(m+1)*k] == unit:
                m += 1
            if m >= min_repeats:
                counts[unit] += 1
                i += m * k
                matched = True
                break
        if not matched:
            i += 1
    return counts

# -----------------------------
# Fetch helpers
# -----------------------------
def fetch_arbitrary(min_len: int, max_len: int) -> Tuple[str, str]:
    ids = search_ids(GENOMIC_TERM.format(min=min_len, max=max_len), retmax=200)
    if not ids:
        raise RuntimeError("No sequences found in range.")
    return fetch_fasta(random.choice(ids))

def fetch_influenza(n: int, min_len: int, max_len: int) -> List[Tuple[str, str]]:
    ids = search_ids(INFLUENZA_TERM.format(min=min_len, max=max_len), retmax=max(50, 5*n))
    if not ids:
        raise RuntimeError("No influenza sequences found.")
    random.shuffle(ids)

    seqs, seen = [], set()
    iterator = tqdm(ids, desc="Fetching influenza", unit="seq") if USE_TQDM else ids
    for seq_id in iterator:
        try:
            title, seq = fetch_fasta(seq_id)
        except Exception:
            continue
        key = tuple(title.split()[:8])
        if key in seen:
            continue
        seen.add(key)
        seqs.append((title, seq))
        if len(seqs) >= n:
            break
    return seqs

# -----------------------------
# Plotting
# -----------------------------
def plot_counts(series: List[Tuple[str, Counter]], title: str, outfile: Path, top: int):
    outfile.parent.mkdir(parents=True, exist_ok=True)
    total = Counter()
    for _, cnt in series:
        total.update(cnt)

    if not total:
        plt.figure(figsize=(10, 4))
        plt.title(f"{title} — no tandem repeats found")
        plt.tight_layout()
        plt.savefig(outfile, dpi=200)
        plt.close()
        return

    labels = [k for k, _ in total.most_common(top)]
    x = np.arange(len(labels))
    width = min(0.8 / max(1, len(series)), 0.25)

    plt.figure(figsize=(max(12, min(24, 0.6 * len(labels) + 4)), 6))
    for i, (name, cnt) in enumerate(series):
        vals = [cnt.get(k, 0) for k in labels]
        plt.bar(x + i * width, vals, width=width, label=name[:30])

    plt.xticks(x + (len(series) - 1) * width / 2, labels, rotation=90)
    plt.title(title)
    plt.xlabel("repeat unit (k=6..10)")
    plt.ylabel("frequency (blocks)")
    plt.legend(title="Genome")
    plt.tight_layout()
    plt.savefig(outfile, dpi=220)
    plt.close()

# -----------------------------
# Main
# -----------------------------
def main():
    random.seed(SEED)
    set_entrez(EMAIL, API_KEY)

    outdir = Path(OUTDIR)
    outdir.mkdir(parents=True, exist_ok=True)

    # 1) Arbitrary DNA sequence
    print("Fetching arbitrary DNA sequence...", file=sys.stderr)
    title, seq = fetch_arbitrary(MIN_LEN, MAX_LEN)
    print(f"Fetched: {title} (len={len(seq)})", file=sys.stderr)
    acounts = detect_tandem_repeats(seq, KMIN, KMAX, MIN_CONSECUTIVE_REPEATS)

    # 2) Influenza sequences
    print(f"\nFetching {INFLUENZA_N} influenza sequences...", file=sys.stderr)
    influenza = fetch_influenza(INFLUENZA_N, MIN_LEN, MAX_LEN)
    print(f"Got {len(influenza)} sequences.", file=sys.stderr)

    series = [("arbitrary", acounts)]
    for i, (ititle, iseq) in enumerate(influenza, start=1):
        print(f"Analyzing influenza {i}/{len(influenza)}", file=sys.stderr)
        icounts = detect_tandem_repeats(iseq, KMIN, KMAX, MIN_CONSECUTIVE_REPEATS)
        series.append((f"influenza_{i}", icounts))

    # 3) Combined plot
    combined_title = f"Tandem repeats across genomes (k={KMIN}..{KMAX})"
    combined_out = outdir / "combined_tandem_repeats.png"
    plot_counts(series, combined_title, combined_out, TOP_N)
    print(f"Plot saved: {combined_out}", file=sys.stderr)

if __name__ == "__main__":
    main()
