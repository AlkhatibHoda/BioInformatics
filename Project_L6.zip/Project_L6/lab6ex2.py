import re
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# === Step 1: Read the FASTA file ===
def read_fasta(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    return ''.join(line.strip() for line in lines if not line.startswith('>'))

# === Load DNA sequence from FASTA ===
sequence = read_fasta("sequence.fasta")

# === Step 2: Define restriction enzymes and recognition sites ===
enzymes = {
    "EcoRI": "GAATTC",
    "BamHI": "GGATCC",
    "HindIII": "AAGCTT",
    "NotI": "GCGGCCGC",
    "XhoI": "CTCGAG"
}

# === Step 3: Find all cut sites ===
cut_sites = []
for name, site in enzymes.items():
    for match in re.finditer(site, sequence):
        cut_sites.append(match.start())

cut_sites = sorted(set(cut_sites))
cut_sites = [0] + cut_sites + [len(sequence)]

# === Step 4: Generate DNA fragments ===
fragments = []
for i in range(len(cut_sites) - 1):
    start = cut_sites[i]
    end = cut_sites[i + 1]
    fragments.append(sequence[start:end])

fragment_lengths = [len(frag) for frag in fragments]

# === Step 5: Visualize gel electrophoresis ===
fig, ax = plt.subplots(figsize=(4, 8))
ax.set_xlim(0, 4)
ax.set_ylim(0, 100)
ax.set_title("Restriction Digest Gel Simulation", fontsize=14)
ax.set_xlabel("Lane", fontsize=12)
ax.set_ylabel("Migration Distance", fontsize=12)
ax.invert_yaxis()
ax.set_facecolor('#f0f8ff')

# Draw gel texture
for y in range(0, 101, 10):
    ax.axhline(y, color='lightgray', linewidth=0.5)

# Draw single lane with bands
max_len = max(fragment_lengths)
for i, length in enumerate(fragment_lengths):
    migration = 100 - (length / max_len) * 80
    ax.add_patch(patches.Rectangle((1.5, migration), 1, 2, color='black'))
    ax.text(2, migration - 2, f"{length} bp", ha='center', fontsize=9)

plt.tight_layout()
plt.savefig("Screenshot_2.jpg")
plt.show()
