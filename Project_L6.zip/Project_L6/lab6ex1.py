import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# === Step 1: Read the FASTA file ===
def read_fasta(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    sequence = ''.join(line.strip() for line in lines if not line.startswith('>'))
    return sequence

# === Step 2: Load DNA sequence ===
dna_sequence = read_fasta("sequence.fasta")

# === Step 3: Generate 10 random DNA fragments ===
samples = []
for _ in range(10):
    length = random.randint(50, 300)
    start = random.randint(0, len(dna_sequence) - length)
    fragment = dna_sequence[start:start + length]
    samples.append(fragment)

# === Step 4: Visualize gel electrophoresis ===
fig, ax = plt.subplots(figsize=(10, 6))
ax.set_xlim(0, 11)
ax.set_ylim(0, 100)
ax.set_title("Gel Electrophoresis Simulation", fontsize=14)
ax.set_xlabel("Lane", fontsize=12)
ax.set_ylabel("Migration Distance", fontsize=12)
ax.invert_yaxis()  # Shorter fragments migrate farther (lower)

# Draw gel background
ax.set_facecolor('#f0f8ff')
for y in range(0, 101, 10):
    ax.axhline(y, color='lightgray', linewidth=0.5)

# Draw lanes and wells
for i in range(1, 11):
    ax.add_patch(patches.Rectangle((i - 0.4, 95), 0.8, 3, color='gray'))  # well
    ax.axvline(i, color='lightgray', linestyle='--', linewidth=0.5)

# Plot bands
max_length = max(len(f) for f in samples)
for i, frag in enumerate(samples):
    length = len(frag)
    migration = 100 - (length / max_length) * 80
    ax.add_patch(patches.Rectangle((i + 1 - 0.3, migration), 0.6, 2, color='black'))
    ax.text(i + 1, migration - 2, f"{length} bp", ha='center', fontsize=9)

plt.tight_layout()
plt.savefig("Screenshot_1.jpg")
plt.show()
