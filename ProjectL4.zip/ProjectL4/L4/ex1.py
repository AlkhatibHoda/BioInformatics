import tkinter as tk
from tkinter import messagebox

# Genetic code dictionary
genetic_code = {
    'UUU': 'Phe', 'UUC': 'Phe', 'UUA': 'Leu', 'UUG': 'Leu',
    'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
    'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile', 'AUG': 'Met',
    'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
    'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
    'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
    'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
    'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
    'UAU': 'Tyr', 'UAC': 'Tyr', 'UAA': 'Stop', 'UAG': 'Stop',
    'CAU': 'His', 'CAC': 'His', 'CAA': 'Gln', 'CAG': 'Gln',
    'AAU': 'Asn', 'AAC': 'Asn', 'AAA': 'Lys', 'AAG': 'Lys',
    'GAU': 'Asp', 'GAC': 'Asp', 'GAA': 'Glu', 'GAG': 'Glu',
    'UGU': 'Cys', 'UGC': 'Cys', 'UGA': 'Stop', 'UGG': 'Trp',
    'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',
    'AGU': 'Ser', 'AGC': 'Ser', 'AGA': 'Arg', 'AGG': 'Arg',
    'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly'
}

def translate_rna(rna_sequence):
    rna_sequence = rna_sequence.upper().replace(" ", "")
    protein = []

    for i in range(0, len(rna_sequence), 3):
        codon = rna_sequence[i:i+3]
        if len(codon) < 3:
            break
        amino_acid = genetic_code.get(codon, '???')
        if amino_acid == 'Stop':
            break
        protein.append(amino_acid)

    return '-'.join(protein)

def on_translate():
    rna_input = entry.get()
    if not rna_input:
        messagebox.showwarning("Input Error", "Please enter an RNA sequence.")
        return
    result = translate_rna(rna_input)
    output_label.config(text=f"Protein: {result}")

# GUI setup
root = tk.Tk()
root.title("RNA to Protein Translator")

tk.Label(root, text="Enter RNA Sequence:").pack(pady=5)
entry = tk.Entry(root, width=40)
entry.pack(pady=5)

translate_button = tk.Button(root, text="Translate", command=on_translate)
translate_button.pack(pady=10)

output_label = tk.Label(root, text="Protein: ", font=("Arial", 12), fg="blue")
output_label.pack(pady=10)

root.mainloop()
