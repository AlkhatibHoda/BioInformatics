# ex2.py
import argparse, re
from collections import Counter
from pathlib import Path
import matplotlib.pyplot as plt

NUC = ["U","C","A","G"]
TABLE_3D = {
    "U":{"U":["F","F","L","L"],"C":["S","S","S","S"],"A":["Y","Y","*","*"],"G":["C","C","*","W"]},
    "C":{"U":["L","L","L","L"],"C":["P","P","P","P"],"A":["H","H","Q","Q"],"G":["R","R","R","R"]},
    "A":{"U":["I","I","I","M"],"C":["T","T","T","T"],"A":["N","N","K","K"],"G":["S","S","R","R"]},
    "G":{"U":["V","V","V","V"],"C":["A","A","A","A"],"A":["D","D","E","E"],"G":["G","G","G","G"]},
}
def build_codon_table():
    t={}
    for n1 in NUC:
        for n2 in NUC:
            for i3,n3 in enumerate(NUC):
                t[f"{n1}{n2}{n3}"]=TABLE_3D[n1][n2][i3]
    return t
CODON2AA=build_codon_table()

def read_fasta_text(path: Path) -> str:
    txt=Path(path).read_text(encoding="utf-8", errors="ignore")
    lines=[ln.strip() for ln in txt.splitlines() if not ln.startswith(">")]
    s="".join(lines).upper()
    s=re.sub(r"[^ACGTU]","",s)
    return s.replace("T","U")

def codon_counts(seq: str, frame: int=1) -> Counter:
    i=frame-1; c=Counter()
    while i+3<=len(seq):
        codon=seq[i:i+3]
        if len(codon)==3: c[codon]+=1
        i+=3
    return c

def counts_to_freq(c: Counter) -> dict:
    tot=sum(c.values())
    return {k:v/tot for k,v in c.items()} if tot else {}

def aa_counts_from_codons(codon_count: Counter) -> Counter:
    aa=Counter()
    for codon,n in codon_count.items():
        a=CODON2AA.get(codon,"X")
        if a!="*": aa[a]+=n
    return aa

def plot_top10(freq: dict, title: str, outpng: Path):
    top10=sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:10]
    labels=[k for k,_ in top10]; values=[v for _,v in top10]
    plt.figure(); plt.bar(range(len(labels)), values)
    plt.xticks(range(len(labels)), labels); plt.ylabel("Frequency"); plt.title(title)
    plt.tight_layout(); plt.savefig(outpng, dpi=150); plt.close()
    return top10

def plot_common(fa: dict, fb: dict, ta, tb, outpng: Path):
    sa={k for k,_ in ta}; sb={k for k,_ in tb}; common=[c for c in sa&sb]
    if not common: return []
    x=range(len(common)); w=0.4
    va=[fa[c] for c in common]; vb=[fb[c] for c in common]
    plt.figure()
    plt.bar([i-w/2 for i in x], va, width=w, label="Genome A")
    plt.bar([i+w/2 for i in x], vb, width=w, label="Genome B")
    plt.xticks(list(x), common); plt.ylabel("Frequency"); plt.title("Common Top Codons – A vs B")
    plt.legend(); plt.tight_layout(); plt.savefig(outpng, dpi=150); plt.close()
    return common

def main():
    ap=argparse.ArgumentParser(description="Codon-usage comparison")
    ap.add_argument("--genome-a", default="COVID-19.fasta")
    ap.add_argument("--genome-b", default="influenza.fasta")
    ap.add_argument("--frame", type=int, choices=[1,2,3], default=1)
    ap.add_argument("--outdir", default=".")
    args=ap.parse_args()

    outdir=Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    seq_a=read_fasta_text(Path(args.genome_a))
    seq_b=read_fasta_text(Path(args.genome_b))

    counts_a=codon_counts(seq_a, frame=args.frame)
    counts_b=codon_counts(seq_b, frame=args.frame)
    freq_a=counts_to_freq(counts_a)
    freq_b=counts_to_freq(counts_b)

    top10_a=plot_top10(freq_a, "Top 10 Codons – Genome A", outdir/"top10_genomeA.png")
    top10_b=plot_top10(freq_b, "Top 10 Codons – Genome B", outdir/"top10_genomeB.png")
    common=plot_common(freq_a, freq_b, top10_a, top10_b, outdir/"common_top_codons.png")

    aa_top3_a=aa_counts_from_codons(counts_a).most_common(3)
    aa_top3_b=aa_counts_from_codons(counts_b).most_common(3)

    print("Top 3 amino acids – Genome A:", aa_top3_a)
    print("Top 3 amino acids – Genome B:", aa_top3_b)
    print("Saved:", outdir/"top10_genomeA.png", outdir/"top10_genomeB.png",
          (outdir/"common_top_codons.png" if common else "no-common-top-codons"))

if __name__=="__main__":
    main()
