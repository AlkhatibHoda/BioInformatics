import numpy as np

def read_int(prompt: str) -> int:
    while True:
        try:
            v = int(input(prompt).strip())
            if v <= 0:
                print("Please enter a positive integer.")
                continue
            return v
        except ValueError:
            print("Invalid integer. Try again.")

def read_row(prompt: str, expected_len: int) -> np.ndarray:
    """
    Reads a single row of numbers from input. Accepts space or comma separated values.
    """
    while True:
        raw = input(prompt).strip().replace(",", " ")
        parts = [p for p in raw.split() if p]
        if len(parts) != expected_len:
            print(f"Expected {expected_len} values, got {len(parts)}. Try again.")
            continue
        try:
            return np.array([float(p) for p in parts], dtype=float)
        except ValueError:
            print("Invalid number found. Try again.")

def main():
    print("=== n-States Prediction Software ===")
    print("We compute x_{k+1} = A x_k for 5 steps.\n")

    n = read_int("Enter number of states n (matrix is n x n): ")

    print("\nEnter matrix A row by row.")
    print("You can separate numbers by spaces or commas.\n")

    A_rows = []
    for i in range(n):
        row = read_row(f"Row {i+1}/{n}: ", n)
        A_rows.append(row)
    A = np.vstack(A_rows)

    print("\nEnter initial vector x0 (length n).")
    x = read_row("x0: ", n)

    steps = 5
    print("\n--- Results ---")
    print(f"x0 = {x}")

    # Compute and print x1..x5
    for k in range(1, steps + 1):
        x = A @ x
        print(f"x{k} = {x}")

    # Optional: show as a table
    # (If you want to store all states, uncomment below)
    # x = read_row("x0: ", n)
    # states = [x.copy()]
    # for _ in range(steps):
    #     x = A @ x
    #     states.append(x.copy())
    # print("\nAs matrix (each row is xk):")
    # print(np.vstack(states))

if __name__ == "__main__":
    main()
