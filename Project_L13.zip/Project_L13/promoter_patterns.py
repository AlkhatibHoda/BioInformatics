import math
from statistics import mean
import matplotlib.pyplot as plt


def clean_sequence(seq: str) -> str:
    seq = seq.upper()
    return "".join(base for base in seq if base in "ACGT")


def sliding_windows(seq: str, window_size: int):
    n = len(seq)
    if window_size > n:
        raise ValueError("Window size larger than sequence length")
    for i in range(n - window_size + 1):
        yield seq[i : i + window_size]



def cg_percent(seq: str) -> float:
    
    seq = clean_sequence(seq)
    if len(seq) == 0:
        return 0.0
    cg = sum(1 for b in seq if b in ("C", "G"))
    return 100.0 * cg / len(seq)


def kappa_ic(seq: str) -> float:
    
    seq = clean_sequence(seq)
    n = len(seq)
    if n < 2:
        return 0.0

    total = 0.0
    for u in range(1, n):  # shift 1..n-1
        s2 = seq[u:]       # suffix
        count = 0
        for i, ch in enumerate(s2):
            if seq[i] == ch:
                count += 1
        total += (count / len(s2)) * 100.0

    ic = round(total / (n - 1), 2)
    return ic



TEST_SEQUENCE = (
    "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
)

def validate_on_test_sequence():
    seq = clean_sequence(TEST_SEQUENCE)
    total_cg = cg_percent(seq)
    total_ic = kappa_ic(seq)

    print("=== VALIDATION ON TEST SEQUENCE ===")
    print(f"Sequence length: {len(seq)} bp")
    print(f"(C+G)% on entire sequence: {total_cg:.2f}")
    print(f"Kappa IC on entire sequence: {total_ic:.2f}")
    print("Target CG ≈ 29.27 (this matches).")
    print("IC target given in assignment is 27.53;")
    print("with the original DNAKAPPA formula we get "
          f"{total_ic:.2f}. If your teacher insists on 27.53,")
    print("they are likely using a slightly different variant/normalisation.")



def build_pattern(seq: str, window_size: int = 30):
    
    seq = clean_sequence(seq)
    cg_values = []
    ic_values = []

    for win in sliding_windows(seq, window_size):
        cg_values.append(cg_percent(win))
        ic_values.append(kappa_ic(win))

    return cg_values, ic_values


def center_of_weight(cg_values, ic_values):
    
    if not cg_values:
        return (0.0, 0.0)
    return (mean(cg_values), mean(ic_values))

def plot_pattern(cg_values, ic_values, title="Promoter pattern"):
    
    plt.figure()
    plt.scatter(cg_values, ic_values, s=10)
    plt.xlabel("(C+G)%")
    plt.ylabel("Kappa IC")
    plt.title(title)
    plt.grid(True)


def plot_pattern_centers(centers, labels=None,
                         title="Centers of promoter patterns"):
    
    if not centers:
        return

    xs = [c[0] for c in centers]
    ys = [c[1] for c in centers]

    plt.figure()
    plt.scatter(xs, ys)

    if labels is not None:
        for (x, y, label) in zip(xs, ys, labels):
            plt.text(x, y, label, fontsize=8, ha="left", va="bottom")

    plt.xlabel("Center (C+G)%")
    plt.ylabel("Center Kappa IC")
    plt.title(title)
    plt.grid(True)

def main():
    validate_on_test_sequence()
    window_size = 30
    cg_vals, ic_vals = build_pattern(TEST_SEQUENCE, window_size)

    print("\n=== PATTERN FOR TEST SEQUENCE ===")
    print(f"Number of windows (size {window_size}): {len(cg_vals)}")
    cx, cy = center_of_weight(cg_vals, ic_vals)
    print(f"Center of weight of pattern: (C+G)% = {cx:.2f}, Kappa IC = {cy:.2f}")

    plot_pattern(cg_vals, ic_vals,
                 title="Pattern of test sequence S")


    promoters = [
        ("Promoter_1", TEST_SEQUENCE),
        ("Promoter_2", TEST_SEQUENCE[::-1]),     # toy example: reversed
        ("Promoter_3", TEST_SEQUENCE[10:])       # toy example: truncated
    ]

    centers = []
    labels = []
    for label, seq in promoters:
        cg, ic = build_pattern(seq, window_size)
        cx, cy = center_of_weight(cg, ic)
        centers.append((cx, cy))
        labels.append(label)
        print(f"{label}: center = ({cx:.2f}, {cy:.2f})")

    plot_pattern_centers(centers, labels,
                         title="Centers of weight of multiple promoters")


    plt.show()


if __name__ == "__main__":
    main()
