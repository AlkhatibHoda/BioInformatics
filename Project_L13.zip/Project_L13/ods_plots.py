import os
import matplotlib.pyplot as plt
from collections import Counter

def read_fasta(path):
    s = ""
    with open(path) as f:
        for line in f:
            if not line.startswith(">"):
                s += line.strip().upper()
    return s

def windows(seq, w=30):
    return [seq[i:i+w] for i in range(0, len(seq) - w + 1)]

def cg_content(seq):
    c = seq.count("C")
    g = seq.count("G")
    return (c + g) / len(seq) * 100

def kappa(seq):
    c = Counter(seq)
    n = len(seq)
    if n < 2:
        return 0.0
    return sum(c[b] * (c[b] - 1) for b in c) / (n * (n - 1))

flu_dir = "FastaFiles"
covid_dir = "covid"

ods = {}
centers = {}

for dir_path in [flu_dir, covid_dir]:
    for fname in sorted(os.listdir(dir_path)):
        if not (fname.endswith(".fasta") or fname.endswith(".fa") or fname.endswith(".fna")):
            continue
        seq = read_fasta(os.path.join(dir_path, fname))
        pts = []
        for w in windows(seq, 30):
            pts.append((cg_content(w), kappa(w)))
        name = fname.split(".")[0]
        ods[name] = pts
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        centers[name] = (cx, cy)
        x = [p[0] for p in pts]
        y = [p[1] for p in pts]
        plt.figure(figsize=(6, 4))
        plt.scatter(x, y, s=5)
        plt.xlabel("CG %")
        plt.ylabel("Kappa index")
        plt.title(name + " ODS")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(name + "_ODS.png", dpi=300)
        plt.close()

plt.figure(figsize=(8, 6))
for name, (cx, cy) in centers.items():
    color = "blue" if name.startswith("flu") else "red"
    plt.scatter(cx, cy, color=color)
    plt.text(cx, cy, name, fontsize=8)
plt.xlabel("CG %")
plt.ylabel("Kappa index")
plt.title("Centers of weight for all ODS")
plt.grid(True)
plt.tight_layout()
plt.show()
