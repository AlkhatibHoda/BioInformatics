from Bio import SeqIO
import random

def read_fasta_sequence(file_path):
    record = SeqIO.read(file_path, "fasta")
    return str(record.seq)

def generate_samples(sequence, num_samples=2000, min_len=100, max_len=150):
    samples = []
    for _ in range(num_samples):
        length = random.randint(min_len, max_len)
        start = random.randint(0, len(sequence) - length)
        sample = sequence[start:start + length]
        samples.append(sample)
    return samples


def save_samples(samples, filename="samples.txt"):
    with open(filename, "w") as f:
        for i, sample in enumerate(samples):
            f.write(f">sample_{i+1}\n{sample}\n")


def reconstruct_sequence(samples):
    reconstructed = samples[0]
    for sample in samples[1:]:
        overlap_found = False
        for i in range(len(sample)):
            if reconstructed.endswith(sample[:i]):
                reconstructed += sample[i:]
                overlap_found = True
                break
        if not overlap_found:
            reconstructed += sample  
    return reconstructed

if __name__ == "__main__":
    
    sequence = read_fasta_sequence("sequence.fasta")
    print("Original sequence length:", len(sequence))

    
    samples = generate_samples(sequence)
    print("Generated", len(samples), "samples.")


    save_samples(samples)
    print("Samples saved to samples.txt")

    
    reconstructed = reconstruct_sequence(samples)
    print("Reconstructed sequence length:", len(reconstructed))
