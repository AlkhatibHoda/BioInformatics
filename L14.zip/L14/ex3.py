import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# ====== CONFIG: how many bases to align (kept small so GUI is fast) ======
MAX_LEN_LONG = 300    # from COVID-19
MAX_LEN_OTHER = 300   # from influenza


# ====== FASTA READER ======

def read_fasta_single(path: str) -> str:
    """Read one-sequence FASTA and return it as an uppercase string."""
    seq_lines = []
    with open(path, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(">"):
                continue
            seq_lines.append(line)
    seq = "".join(seq_lines).upper()
    if not seq:
        raise ValueError(f"No sequence data found in {path}")
    return seq


# ====== SMITH–WATERMAN (with matrix + path) ======

def smith_waterman_full(seq1: str, seq2: str,
                        match: int = 2,
                        mismatch: int = -1,
                        gap: int = -2):
    """
    Smith–Waterman local alignment.
    Returns:
      aln1, aln2, best_score, H, path
    where H is the score matrix and path is list of (i,j) cells.
    """
    n, m = len(seq1), len(seq2)
    H = np.zeros((n + 1, m + 1), dtype=np.int32)
    T = np.zeros((n + 1, m + 1), dtype=np.uint8)  # 0 stop, 1 diag, 2 up, 3 left

    best_score = 0
    bi = bj = 0

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            diag = H[i-1, j-1] + (match if seq1[i-1] == seq2[j-1] else mismatch)
            up = H[i-1, j] + gap
            left = H[i, j-1] + gap
            val = max(0, diag, up, left)

            H[i, j] = val
            if val == 0:
                T[i, j] = 0
            elif val == diag:
                T[i, j] = 1
            elif val == up:
                T[i, j] = 2
            else:
                T[i, j] = 3

            if val > best_score:
                best_score = val
                bi, bj = i, j

    # traceback from best cell
    i, j = bi, bj
    aln1, aln2 = [], []
    path = [(i, j)]

    while i > 0 and j > 0 and H[i, j] > 0:
        d = T[i, j]
        if d == 1:  # diag
            aln1.append(seq1[i-1])
            aln2.append(seq2[j-1])
            i -= 1; j -= 1
        elif d == 2:  # up
            aln1.append(seq1[i-1])
            aln2.append("-")
            i -= 1
        elif d == 3:  # left
            aln1.append("-")
            aln2.append(seq2[j-1])
            j -= 1
        else:
            break
        path.append((i, j))

    aln1 = "".join(reversed(aln1))
    aln2 = "".join(reversed(aln2))
    path = path[::-1]  # from start to end

    return aln1, aln2, best_score, H, path


# ====== SCORING EQUATIONS ======

def compute_similarity_scores(aln1: str, aln2: str,
                              score: int,
                              match_score: int = 2,
                              gap_weight: float = 0.5):
    """
    Compute:
      M, X, G, L
      Eq1: PI  = M / L * 100
      Eq2: GPS = (M - gap_weight * G) / L * 100
      Eq3: NAS = score / (L * match_score) * 100
    """
    M = X = G = 0
    for a, b in zip(aln1, aln2):
        if a == "-" or b == "-":
            G += 1
        elif a == b:
            M += 1
        else:
            X += 1

    L = len(aln1)
    if L == 0:
        return dict(M=0, X=0, G=0, L=0, PI=0.0, GPS=0.0, NAS=0.0)

    PI = M / L * 100.0
    gps_num = M - gap_weight * G
    if gps_num < 0:
        gps_num = 0.0
    GPS = gps_num / L * 100.0
    max_score = L * match_score if match_score > 0 else 1
    NAS = score / max_score * 100.0

    return dict(M=M, X=X, G=G, L=L, PI=PI, GPS=GPS, NAS=NAS)


# ====== GUI CLASS ======

class Ex3SmallGUI:
    def __init__(self, root):
        self.root = root
        root.title("Exercise 3 – Similarity + Diagrams (Small, Fast)")

        # --- load sequences from FASTA ---
        try:
            influenza_full = read_fasta_single("influenza.fasta")
            covid_full = read_fasta_single("COVID-19.fasta")
        except Exception as e:
            messagebox.showerror("FASTA error", str(e))
            root.destroy()
            return

        # choose long vs other (we still truncate for speed)
        if len(covid_full) >= len(influenza_full):
            self.long_name = "COVID-19.fasta"
            self.other_name = "influenza.fasta"
            self.seq_long = covid_full[:MAX_LEN_LONG]
            self.seq_other = influenza_full[:MAX_LEN_OTHER]
        else:
            self.long_name = "influenza.fasta"
            self.other_name = "COVID-19.fasta"
            self.seq_long = influenza_full[:MAX_LEN_LONG]
            self.seq_other = covid_full[:MAX_LEN_OTHER]

        # --- layout ---

        main = ttk.Frame(root, padding=10)
        main.pack(fill="both", expand=True)

        top = ttk.Frame(main)
        top.pack(side="top", fill="x")

        info_text = (
            f"{self.long_name} (long, truncated to {len(self.seq_long)} bp)\n"
            f"{self.other_name} (truncated to {len(self.seq_other)} bp)"
        )
        ttk.Label(top, text=info_text).pack(side="left")

        ttk.Button(top, text="Align & Score", command=self.run_alignment).pack(
            side="right", padx=10
        )

        # alignment + scores text
        self.aln_text = tk.Text(main, height=14, width=100, font=("Courier New", 10))
        self.aln_text.pack(fill="x", pady=5)

        # score matrix figure
        fig1 = Figure(figsize=(4, 3))
        self.ax_matrix = fig1.add_subplot(111)
        self.canvas_matrix = FigureCanvasTkAgg(fig1, master=main)
        self.canvas_matrix.get_tk_widget().pack(side="left", padx=5, pady=5)

        # traceback figure
        fig2 = Figure(figsize=(4, 3))
        self.ax_path = fig2.add_subplot(111)
        self.canvas_path = FigureCanvasTkAgg(fig2, master=main)
        self.canvas_path.get_tk_widget().pack(side="left", padx=5, pady=5)

    def run_alignment(self):
        self.aln_text.delete("1.0", "end")

        # 1) run SW on truncated sequences
        aln1, aln2, score, H, path = smith_waterman_full(
            self.seq_long, self.seq_other,
            match=2, mismatch=-1, gap=-2
        )

        # 2) compute similarity scores
        metrics = compute_similarity_scores(
            aln1, aln2, score=score,
            match_score=2, gap_weight=0.5
        )

        # 3) build alignment text with equations
        match_line = "".join(
            "|" if a == b and a != "-" and b != "-" else " "
            for a, b in zip(aln1, aln2)
        )

        lines = []
        lines.append("=== Alignment statistics ===")
        lines.append(f"Raw SW score (S)          = {score}")
        lines.append(f"M (matches)               = {metrics['M']}")
        lines.append(f"X (mismatches)            = {metrics['X']}")
        lines.append(f"G (gaps)                  = {metrics['G']}")
        lines.append(f"L (alignment length)      = {metrics['L']}")
        lines.append("")
        lines.append("Scoring equations:")
        lines.append("  Eq1: PI  = M / L * 100")
        lines.append("  Eq2: GPS = (M - 0.5 * G) / L * 100")
        lines.append("  Eq3: NAS = S / (L * s_match) * 100, s_match = 2")
        lines.append("")
        lines.append(f"PI  = {metrics['PI']:.2f} %")
        lines.append(f"GPS = {metrics['GPS']:.2f} %")
        lines.append(f"NAS = {metrics['NAS']:.2f} %")
        lines.append("")
        lines.append("=== Alignment ===")
        lines.append(aln1)
        lines.append(match_line)
        lines.append(aln2)

        self.aln_text.insert("end", "\n".join(lines))

        # 4) draw score matrix heatmap
        self.ax_matrix.clear()
        self.ax_matrix.imshow(H, cmap="viridis", origin="upper")
        self.ax_matrix.set_title("Score Matrix (Smith–Waterman)")
        self.ax_matrix.set_xlabel("j (other sequence)")
        self.ax_matrix.set_ylabel("i (long sequence)")
        self.canvas_matrix.draw()

        # 5) draw traceback path on top of matrix
        self.ax_path.clear()
        self.ax_path.imshow(H, cmap="Greys", origin="upper")
        ys = [p[0] for p in path]
        xs = [p[1] for p in path]
        self.ax_path.plot(xs, ys, color="red", linewidth=2)
        self.ax_path.set_title("Traceback Path")
        self.ax_path.set_xlabel("j")
        self.ax_path.set_ylabel("i")
        self.canvas_path.draw()


# ====== MAIN ======

if __name__ == "__main__":
    root = tk.Tk()
    app = Ex3SmallGUI(root)
    root.mainloop()
