import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# -----------------------------------------------------------
#  FASTA READER
#  (works with influenza.fasta and COVID-19.fasta in same folder)
# -----------------------------------------------------------

def read_fasta_single(path: str) -> str:
    """
    Read a single-sequence FASTA file and return the DNA string (uppercase).
    Assumes the file was already downloaded from NCBI.
    """
    seq_lines = []
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith(">"):
                    continue
                seq_lines.append(line)
    except FileNotFoundError:
        raise FileNotFoundError(f"FASTA file not found: {path}")
    seq = "".join(seq_lines).upper()
    if not seq:
        raise ValueError(f"No sequence data found in {path}")
    return seq


# -----------------------------------------------------------
#  SMITH–WATERMAN LOCAL ALIGNMENT
# -----------------------------------------------------------

def smith_waterman(seq1: str, seq2: str,
                   match: int = 2,
                   mismatch: int = -1,
                   gap: int = -2):
    """
    Classic Smith–Waterman local alignment between seq1 and seq2.

    Returns:
        aln1, aln2, best_score, (i_start, i_end, j_start, j_end)
    where i indexes seq1 and j indexes seq2.
    """
    n, m = len(seq1), len(seq2)

    # score matrix H and traceback matrix T
    # T: 0 = stop, 1 = diag, 2 = up, 3 = left
    H = np.zeros((n + 1, m + 1), dtype=int)
    T = np.zeros((n + 1, m + 1), dtype=np.uint8)

    best_score = 0
    best_pos = (0, 0)

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            diag = H[i - 1, j - 1] + (match if seq1[i - 1] == seq2[j - 1] else mismatch)
            up = H[i - 1, j] + gap
            left = H[i, j - 1] + gap
            val = max(0, diag, up, left)

            H[i, j] = val
            if val == 0:
                T[i, j] = 0
            elif val == diag:
                T[i, j] = 1
            elif val == up:
                T[i, j] = 2
            else:
                T[i, j] = 3

            if val > best_score:
                best_score = val
                best_pos = (i, j)

    # traceback
    i, j = best_pos
    aln1, aln2 = [], []
    i_end, j_end = i, j

    while i > 0 and j > 0 and H[i, j] > 0:
        direction = T[i, j]
        if direction == 1:          # diag
            aln1.append(seq1[i - 1])
            aln2.append(seq2[j - 1])
            i -= 1
            j -= 1
        elif direction == 2:        # up
            aln1.append(seq1[i - 1])
            aln2.append("-")
            i -= 1
        elif direction == 3:        # left
            aln1.append("-")
            aln2.append(seq2[j - 1])
            j -= 1
        else:                       # 0 = stop
            break

    i_start, j_start = i, j
    aln1 = "".join(reversed(aln1))
    aln2 = "".join(reversed(aln2))

    return aln1, aln2, int(best_score), (i_start, i_end, j_start, j_end)


# -----------------------------------------------------------
#  IN-BETWEEN LAYER: CHUNKED LOCAL ALIGNMENT
#  (step-by-step on big regions with connection between results)
# -----------------------------------------------------------

def chunked_local_alignment(long_seq: str,
                            other_seq: str,
                            window: int = 4000,
                            step: int = 2000,
                            min_score: int = 40,
                            progress_callback=None):
    """
    Align a big genome (long_seq, here COVID-19) to another genome
    (other_seq, here influenza) using Smith–Waterman on overlapping windows.

    This is the required 'in-between' layer that allows local alignment
    of very long sequences by processing them step by step.

    Returns a list of blocks:
        {
          'i_start', 'i_end',        # coords in long_seq (big genome)
          'j_start', 'j_end',        # coords in other_seq
          'score', 'aln1', 'aln2'
        }
    """
    results = []
    n = len(long_seq)

    for win_start in range(0, n, step):
        win_end = min(win_start + window, n)
        sub = long_seq[win_start:win_end]
        if not sub:
            break

        if progress_callback:
            progress_callback(f"Aligning window {win_start}-{win_end} …")

        aln1, aln2, score, (i_s, i_e, j_s, j_e) = smith_waterman(sub, other_seq)

        if score >= min_score and aln1.strip("-"):
            results.append({
                "i_start": win_start + i_s,
                "i_end": win_start + i_e,
                "j_start": j_s,
                "j_end": j_e,
                "score": score,
                "aln1": aln1,
                "aln2": aln2
            })

    # sort blocks along long genome
    results.sort(key=lambda b: b["i_start"])
    return results


# -----------------------------------------------------------
#  GUI APPLICATION
# -----------------------------------------------------------

class GenomeAlignGUI:
    def __init__(self, root):
        self.root = root
        root.title("Influenza vs COVID-19 – Local Alignment")

        # load sequences immediately from local FASTA files
        try:
            self.influenza_seq = read_fasta_single("influenza.fasta")
            self.covid_seq = read_fasta_single("COVID-19.fasta")
        except Exception as e:
            messagebox.showerror("Error loading FASTA files", str(e))
            root.destroy()
            return

        # decide which is long genome (COVID-19 is longer)
        if len(self.covid_seq) >= len(self.influenza_seq):
            self.long_name = "COVID-19.fasta"
            self.long_seq = self.covid_seq
            self.other_name = "influenza.fasta"
            self.other_seq = self.influenza_seq
        else:
            self.long_name = "influenza.fasta"
            self.long_seq = self.influenza_seq
            self.other_name = "COVID-19.fasta"
            self.other_seq = self.covid_seq

        self.blocks = []
        self.long_len = len(self.long_seq)

        # --- layout ---
        main = ttk.Frame(root, padding=10)
        main.pack(fill="both", expand=True)

        left = ttk.Frame(main)
        left.grid(row=0, column=0, sticky="nsw")

        # Info label (lengths)
        info_text = (f"{self.other_name}: {len(self.other_seq)} bp\n"
                     f"{self.long_name}: {len(self.long_seq)} bp (long genome)")
        self.info_label = ttk.Label(left, text=info_text)
        self.info_label.grid(row=0, column=0, columnspan=2, pady=4)

        # Run button
        ttk.Button(left, text="Run Local Alignment",
                   command=self.run_alignment_gui).grid(row=1, column=0,
                                                        columnspan=2,
                                                        pady=6, sticky="ew")

        # progress text (shows step-by-step windows)
        self.progress = tk.Text(left, width=48, height=7)
        self.progress.grid(row=2, column=0, columnspan=2, pady=4)

        # list of blocks (connection between step results)
        self.block_list = tk.Listbox(left, width=48, height=12)
        self.block_list.grid(row=3, column=0, columnspan=2, pady=4)
        self.block_list.bind("<<ListboxSelect>>", self.show_block)

        # right side
        right = ttk.Frame(main)
        right.grid(row=0, column=1, padx=10, sticky="nsew")
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        # plot of blocks along long genome
        self.fig = Figure(figsize=(6, 2), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_xlabel("Position on long genome (bp)")
        self.ax.get_yaxis().set_visible(False)

        self.canvas = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas.get_tk_widget().pack(fill="x")

        # alignment text display
        self.aln_display = tk.Text(right, width=80, height=24,
                                   font=("Courier New", 10))
        self.aln_display.pack(fill="both", expand=True, pady=4)

    # small helper for logging
    def log(self, text: str):
        self.progress.insert("end", text + "\n")
        self.progress.see("end")
        self.root.update_idletasks()

    # run chunked alignment
    def run_alignment_gui(self):
        self.progress.delete("1.0", "end")
        self.block_list.delete(0, "end")
        self.aln_display.delete("1.0", "end")
        self.blocks = []

        self.log("--- Starting chunked local alignment ---")
        self.log(f"Long genome : {self.long_name} ({self.long_len} bp)")
        self.log(f"Other genome: {self.other_name} ({len(self.other_seq)} bp)")

        blocks = chunked_local_alignment(
            self.long_seq,
            self.other_seq,
            window=4000,      # big regions of 4000 bp
            step=2000,        # 50% overlap
            min_score=40,     # ignore very small random hits
            progress_callback=self.log
        )

        self.blocks = blocks

        if not blocks:
            self.block_list.insert("end", "No blocks found (score < 40).")
            self.draw_blocks_plot([])
            return

        for i, blk in enumerate(blocks):
            label = (f"[{i}] score={blk['score']} | "
                     f"{self.long_name} {blk['i_start']}..{blk['i_end']}")
            self.block_list.insert("end", label)

        self.draw_blocks_plot(blocks)

    # plot blocks along long genome (connection between results)
    def draw_blocks_plot(self, blocks):
        self.ax.clear()
        self.ax.set_title(f"Local alignment blocks on {self.long_name}")
        self.ax.set_xlabel("Position on long genome (bp)")
        self.ax.get_yaxis().set_visible(False)

        # line representing whole genome
        self.ax.hlines(1, 0, max(self.long_len, 1), linewidth=2)

        # each block as a thick segment
        for blk in blocks:
            self.ax.plot([blk["i_start"], blk["i_end"]], [1, 1],
                         linewidth=8)

        self.ax.set_xlim(0, max(self.long_len, 1))
        self.ax.set_ylim(0.5, 1.5)
        self.fig.tight_layout()
        self.canvas.draw()

    # show alignment for selected block, with matches & similarity %
    def show_block(self, event):
        sel = self.block_list.curselection()
        if not sel or not self.blocks:
            return
        idx = sel[0]
        if idx >= len(self.blocks):
            return

        blk = self.blocks[idx]
        aln1 = blk["aln1"]
        aln2 = blk["aln2"]

        match_line = "".join(
            "|" if a == b and a != "-" and b != "-" else " "
            for a, b in zip(aln1, aln2)
        )
        matches = sum(1 for a, b in zip(aln1, aln2)
                      if a == b and a != "-" and b != "-")
        length = len(aln1)
        similarity = (matches / length * 100) if length > 0 else 0.0

        lines = [
            f"Score      : {blk['score']}",
            f"{self.long_name}  : {blk['i_start']}..{blk['i_end']}",
            f"{self.other_name} : {blk['j_start']}..{blk['j_end']}",
            f"Matches    : {matches}",
            f"Length     : {length}",
            f"Similarity : {similarity:.1f} %",
            "",
            aln1,
            match_line,
            aln2,
        ]

        self.aln_display.delete("1.0", "end")
        self.aln_display.insert("end", "\n".join(lines))


# -----------------------------------------------------------
#  MAIN
# -----------------------------------------------------------

if __name__ == "__main__":
    root = tk.Tk()
    app = GenomeAlignGUI(root)
    root.mainloop()
