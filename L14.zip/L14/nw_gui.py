import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# -------------------- Needleman–Wunsch core -------------------- #

def needleman_wunsch(seq1, seq2, match=1, mismatch=-1, gap=-1):
    n, m = len(seq1), len(seq2)

    score = [[0] * (m + 1) for _ in range(n + 1)]
    traceback = [[None] * (m + 1) for _ in range(n + 1)]

    # init first column
    for i in range(1, n + 1):
        score[i][0] = i * gap
        traceback[i][0] = 'U'  # from up  (gap in seq2)

    # init first row
    for j in range(1, m + 1):
        score[0][j] = j * gap
        traceback[0][j] = 'L'  # from left (gap in seq1)

    # fill matrix
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if seq1[i - 1] == seq2[j - 1]:
                diag = score[i - 1][j - 1] + match
            else:
                diag = score[i - 1][j - 1] + mismatch

            up = score[i - 1][j] + gap
            left = score[i][j - 1] + gap

            best = max(diag, up, left)
            score[i][j] = best

            if best == diag:
                traceback[i][j] = 'D'
            elif best == up:
                traceback[i][j] = 'U'
            else:
                traceback[i][j] = 'L'

    # traceback (also record path for drawing)
    i, j = n, m
    align1 = []
    align2 = []
    path = []

    while i > 0 or j > 0:
        path.append((i, j))
        direction = traceback[i][j]
        if direction == 'D':
            align1.append(seq1[i - 1])
            align2.append(seq2[j - 1])
            i -= 1
            j -= 1
        elif direction == 'U':
            align1.append(seq1[i - 1])
            align2.append('-')
            i -= 1
        elif direction == 'L':
            align1.append('-')
            align2.append(seq2[j - 1])
            j -= 1
        else:
            break

    path.append((0, 0))
    path = path[::-1]

    align1 = ''.join(align1[::-1])
    align2 = ''.join(align2[::-1])

    return align1, align2, score, path


# -------------------- GUI Application -------------------- #

class NWGuiApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Needleman–Wunsch DNA Alignment")
        self.geometry("1100x600")

        self._build_widgets()

    def _build_widgets(self):
        main = ttk.Frame(self, padding=5)
        main.pack(fill=tk.BOTH, expand=True)

        # Left: controls
        left = ttk.Frame(main)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)

        ttk.Label(left, text="Seq 1:").grid(row=0, column=0, sticky="w")
        self.seq1_var = tk.StringVar(value="ACCGTGAAGCCAATAC")
        ttk.Entry(left, textvariable=self.seq1_var, width=35).grid(row=0, column=1, pady=2)

        ttk.Label(left, text="Seq 2:").grid(row=1, column=0, sticky="w")
        self.seq2_var = tk.StringVar(value="AGCGTGACGCCAATAC")
        ttk.Entry(left, textvariable=self.seq2_var, width=35).grid(row=1, column=1, pady=2)

        ttk.Label(left, text="Gap:").grid(row=2, column=0, sticky="w")
        self.gap_var = tk.StringVar(value="-1")
        ttk.Entry(left, textvariable=self.gap_var, width=8).grid(row=2, column=1, sticky="w")

        ttk.Label(left, text="Match:").grid(row=3, column=0, sticky="w")
        self.match_var = tk.StringVar(value="1")
        ttk.Entry(left, textvariable=self.match_var, width=8).grid(row=3, column=1, sticky="w")

        ttk.Label(left, text="Mismatch:").grid(row=4, column=0, sticky="w")
        self.mismatch_var = tk.StringVar(value="-1")
        ttk.Entry(left, textvariable=self.mismatch_var, width=8).grid(row=4, column=1, sticky="w")

        ttk.Button(left, text="Align", command=self.run_alignment).grid(
            row=5, column=0, columnspan=2, pady=10, sticky="we"
        )

        # Right side: plots + alignment text
        right = ttk.Frame(main)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Matplotlib figure
        self.fig = Figure(figsize=(6, 3), dpi=100)
        self.ax_score = self.fig.add_subplot(1, 2, 1)
        self.ax_path = self.fig.add_subplot(1, 2, 2)

        self.canvas = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Alignment text box
        self.text = tk.Text(right, height=10, font=("Courier New", 10))
        self.text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    def run_alignment(self):
        seq1 = self.seq1_var.get().strip().upper()
        seq2 = self.seq2_var.get().strip().upper()

        if not seq1 or not seq2:
            messagebox.showerror("Error", "Both sequences must be non-empty.")
            return

        try:
            gap = int(self.gap_var.get())
            match = int(self.match_var.get())
            mismatch = int(self.mismatch_var.get())
        except ValueError:
            messagebox.showerror("Error", "Gap, match and mismatch must be integers.")
            return

        align1, align2, score_matrix, path = needleman_wunsch(seq1, seq2, match, mismatch, gap)

        # ----- update text alignment view -----
        matches_line = []
        matches = 0
        for a, b in zip(align1, align2):
            if a == b and a != '-' and b != '-':
                matches_line.append('|')
                matches += 1
            else:
                matches_line.append(' ')
        matches_line = ''.join(matches_line)
        length = len(align1)
        similarity = matches / length * 100 if length > 0 else 0

        self.text.delete("1.0", tk.END)
        self.text.insert(tk.END, "Alignment:\n")
        self.text.insert(tk.END, align1 + "\n")
        self.text.insert(tk.END, matches_line + "\n")
        self.text.insert(tk.END, align2 + "\n\n")
        self.text.insert(tk.END, f"Matches = {matches}\n")
        self.text.insert(tk.END, f"Length  = {length}\n")
        self.text.insert(tk.END, f"Similarity = {similarity:.1f} %\n")

        # ----- update plots -----
        score_np = np.array(score_matrix)

        # score heatmap
        self.ax_score.clear()
        im1 = self.ax_score.imshow(score_np, origin="upper")
        self.ax_score.set_title("Score matrix")
        self.ax_score.set_xlabel("j (Seq2)")
        self.ax_score.set_ylabel("i (Seq1)")
        self.fig.colorbar(im1, ax=self.ax_score, fraction=0.046, pad=0.04)

        # traceback path matrix (1 on path, 0 otherwise)
        path_matrix = np.zeros_like(score_np)
        for (i, j) in path:
            path_matrix[i, j] = 1

        self.ax_path.clear()
        self.ax_path.imshow(path_matrix, origin="upper")
        self.ax_path.set_title("Traceback path")
        self.ax_path.set_xlabel("j (Seq2)")
        self.ax_path.set_ylabel("i (Seq1)")

        self.fig.tight_layout()
        self.canvas.draw()


if __name__ == "__main__":
    app = NWGuiApp()
    app.mainloop()
